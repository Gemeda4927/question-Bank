'use client';
import { ReactNode } from 'react';
import { useRouter } from 'next/navigation';

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const router = useRouter();

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.replace('/login');
  };

  const menuItems = [
    { name: 'Dashboard', path: '/dashboard/admin' },
    { name: 'Users', path: '/dashboard/admin/users' },
    { name: 'Universities', path: '/dashboard/admin/universities' },
    { name: 'Programs', path: '/dashboard/admin/programs' },
    { name: 'Departments', path: '/dashboard/admin/departments' },
    { name: 'Courses', path: '/dashboard/admin/courses' },
    { name: 'Colleges', path: '/dashboard/admin/colleges' },
    { name: 'Faculty', path: '/dashboard/admin/faculty' },
    { name: 'Payments', path: '/dashboard/admin/payments' },
    { name: 'Exams', path: '/dashboard/admin/exams' },
    { name: 'Questions', path: '/dashboard/admin/questions' },
  ];

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-700 text-white flex flex-col">
        <div className="p-6 text-2xl font-bold">Admin Panel</div>
        <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
          {menuItems.map((item) => (
            <button
              key={item.name}
              className="block w-full text-left px-3 py-2 rounded hover:bg-blue-600 transition text-sm"
              onClick={() => router.push(item.path)}
            >
              {item.name}
            </button>
          ))}
        </nav>
        <button
          onClick={handleLogout}
          className="m-4 px-3 py-2 bg-red-600 rounded hover:bg-red-700 transition"
        >
          Logout
        </button>
      </aside>

      {/* Main content */}
      <main className="flex-1 p-8 overflow-auto">
        {children}
      </main>
    </div>
  );
}