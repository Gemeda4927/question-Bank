'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import UserForm from '@/components/forms/UserForm';
import { adminService } from '@/services/adminService';

export default function UsersPage() {
  const userColumns = [
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'role', label: 'Role' },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
    { 
      key: 'isDeleted', 
      label: 'Status',
      render: (value: boolean) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
        }`}>
          {value ? 'Deleted' : 'Active'}
        </span>
      )
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Users Management</h1>
          <p className="text-gray-600 mt-2">Manage system users, their roles and permissions</p>
        </div>
        
        <DataTable 
          endpoint="getUsers"
          title="All Users"
          columns={userColumns}
          service={adminService}
          createForm={UserForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}