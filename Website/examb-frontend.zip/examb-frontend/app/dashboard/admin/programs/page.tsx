'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import ProgramForm from '@/components/forms/ProgramForm';

export default function ProgramsPage() {
  const programColumns = [
    { key: 'name', label: 'Program Name' },
    { key: 'code', label: 'Code' },
    { key: 'departmentId', label: 'Department ID' },
    { key: 'degreeType', label: 'Degree Type' },
    { key: 'duration', label: 'Duration (years)' },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Programs Management</h1>
          <p className="text-gray-600 mt-2">Manage academic programs</p>
        </div>
        
        <DataTable 
          endpoint="getPrograms"
          title="All Programs"
          columns={programColumns}
          service={adminService}
          createForm={ProgramForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}