'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import ExamForm from '@/components/forms/ExamForm';

export default function ExamsPage() {
  const examColumns = [
    { key: 'title', label: 'Exam Title' },
    { key: 'courseId', label: 'Course ID' },
    { key: 'duration', label: 'Duration (min)' },
    { key: 'totalMarks', label: 'Total Marks' },
    { 
      key: 'scheduledAt', 
      label: 'Scheduled At',
      render: (value: string) => value ? new Date(value).toLocaleString() : 'Not scheduled'
    },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Exams Management</h1>
          <p className="text-gray-600 mt-2">Manage exams and schedules</p>
        </div>
        
        <DataTable 
          endpoint="getExams"
          title="All Exams"
          columns={examColumns}
          service={adminService}
          createForm={ExamForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}