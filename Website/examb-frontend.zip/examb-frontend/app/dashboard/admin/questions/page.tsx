'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import QuestionForm from '@/components/forms/QuestionForm';

export default function QuestionsPage() {
  const questionColumns = [
    { 
      key: 'questionText', 
      label: 'Question',
      render: (value: string) => value.length > 50 ? `${value.substring(0, 50)}...` : value
    },
    { key: 'examId', label: 'Exam ID' },
    { key: 'questionType', label: 'Type' },
    { key: 'marks', label: 'Marks' },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Questions Management</h1>
          <p className="text-gray-600 mt-2">Manage exam questions</p>
        </div>
        
        <DataTable 
          endpoint="getQuestions"
          title="All Questions"
          columns={questionColumns}
          service={adminService}
          createForm={QuestionForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}