"use client";
import AdminLayout from "@/components/AdminLayout";
import ProtectedRoute from "@/components/ProtectedRoute";
import DataTable from "@/components/DataTable";
import { adminService } from "@/services/adminService";
import CollegeForm from "@/components/forms/CollegeForm";

export default function CollegesPage() {
  const collegeColumns = [
    { key: "name", label: "College Name" },
    { key: "code", label: "Code" },
    {
      key: "universityId",
      label: "University ID",
    },
    {
      key: "createdAt",
      label: "Created At",
      render: (value: string) =>
        new Date(value).toLocaleDateString(),
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">
            Colleges Management
          </h1>
          <p className="text-gray-600 mt-2">
            Manage colleges within universities
          </p>
        </div>

        <DataTable
          endpoint="getColleges"
          title="All Colleges"
          columns={collegeColumns}
          service={adminService}
          createForm={CollegeForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}
