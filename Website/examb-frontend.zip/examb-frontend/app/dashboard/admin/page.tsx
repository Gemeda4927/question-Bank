'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useEffect, useState } from 'react';
import { adminService } from '@/services/adminService';

interface Stats {
  totalUsers: number;
  totalUniversities: number;
  totalExams: number;
  totalCourses: number;
  totalQuestions: number;
  totalPayments: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const [usersRes, universitiesRes, examsRes, coursesRes, questionsRes, paymentsRes] = await Promise.all([
        adminService.getUsers(),
        adminService.getUniversities(),
        adminService.getExams(),
        adminService.getCourses(),
        adminService.getQuestions(),
        adminService.getPayments()
      ]);

      setStats({
        totalUsers: usersRes.data.totalCount || usersRes.data.length,
        totalUniversities: universitiesRes.data.totalCount || universitiesRes.data.length,
        totalExams: examsRes.data.totalCount || examsRes.data.length,
        totalCourses: coursesRes.data.totalCount || coursesRes.data.length,
        totalQuestions: questionsRes.data.totalCount || questionsRes.data.length,
        totalPayments: paymentsRes.data.totalCount || paymentsRes.data.length,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { title: 'Total Users', value: stats?.totalUsers, color: 'blue', path: '/dashboard/admin/users' },
    { title: 'Universities', value: stats?.totalUniversities, color: 'green', path: '/dashboard/admin/universities' },
    { title: 'Exams', value: stats?.totalExams, color: 'purple', path: '/dashboard/admin/exams' },
    { title: 'Courses', value: stats?.totalCourses, color: 'orange', path: '/dashboard/admin/courses' },
    { title: 'Questions', value: stats?.totalQuestions, color: 'indigo', path: '/dashboard/admin/questions' },
    { title: 'Payments', value: stats?.totalPayments, color: 'pink', path: '/dashboard/admin/payments' },
  ];

  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    purple: 'bg-purple-500',
    orange: 'bg-orange-500',
    indigo: 'bg-indigo-500',
    pink: 'bg-pink-500',
  };

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-gray-600 mb-8">Welcome to the ExamB administration panel</p>

        {/* Statistics Cards */}
        {!loading && stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {statCards.map((stat) => (
              <div 
                key={stat.title}
                onClick={() => window.location.href = stat.path}
                className="bg-white p-6 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center">
                  <div className={`p-3 rounded-full ${colorClasses[stat.color as keyof typeof colorClasses]} bg-opacity-10`}>
                    <div className={`w-6 h-6 ${colorClasses[stat.color as keyof typeof colorClasses]} rounded-full`}></div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-semibold text-gray-700">{stat.title}</h3>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Quick Actions */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <button 
              onClick={() => window.location.href = '/dashboard/admin/users'}
              className="p-4 border rounded-lg hover:bg-gray-50 transition text-left"
            >
              <h3 className="font-semibold">Manage Users</h3>
              <p className="text-sm text-gray-600">Add, edit, or remove users</p>
            </button>
            <button 
              onClick={() => window.location.href = '/dashboard/admin/universities'}
              className="p-4 border rounded-lg hover:bg-gray-50 transition text-left"
            >
              <h3 className="font-semibold">Manage Universities</h3>
              <p className="text-sm text-gray-600">Handle university data</p>
            </button>
            <button 
              onClick={() => window.location.href = '/dashboard/admin/exams'}
              className="p-4 border rounded-lg hover:bg-gray-50 transition text-left"
            >
              <h3 className="font-semibold">Manage Exams</h3>
              <p className="text-sm text-gray-600">Create and manage exams</p>
            </button>
          </div>
        </div>
      </AdminLayout>
    </ProtectedRoute>
  );
}