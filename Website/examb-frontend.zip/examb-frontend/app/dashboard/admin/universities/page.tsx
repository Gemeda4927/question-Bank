"use client";
import AdminLayout from "@/components/AdminLayout";
import ProtectedRoute from "@/components/ProtectedRoute";
import DataTable from "@/components/DataTable";
import { adminService } from "@/services/adminService";
import UniversityForm from "@/components/forms/UniversityForm";

export default function UniversitiesPage() {
  const universityColumns = [
    { key: "name", label: "University Name" },
    { key: "code", label: "Code" },
    { key: "location", label: "Location" },
    {
      key: "createdAt",
      label: "Created At",
      render: (value: string) =>
        new Date(value).toLocaleDateString(),
    },
    {
      key: "isDeleted",
      label: "Status",
      render: (value: boolean) => (
        <span
          className={`px-2 py-1 rounded-full text-xs ${
            value
              ? "bg-red-100 text-red-800"
              : "bg-green-100 text-green-800"
          }`}
        >
          {value ? "Deleted" : "Active"}
        </span>
      ),
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">
            Universities Management
          </h1>
          <p className="text-gray-600 mt-2">
            Manage universities and their
            information
          </p>
        </div>

        <DataTable
          endpoint="getUniversities"
          title="All Universities"
          columns={universityColumns}
          service={adminService}
          createForm={UniversityForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}
