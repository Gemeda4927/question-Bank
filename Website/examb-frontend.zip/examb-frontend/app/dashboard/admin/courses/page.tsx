'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import CourseForm from '@/components/forms/CourseForm';

export default function CoursesPage() {
  const courseColumns = [
    { key: 'name', label: 'Course Name' },
    { key: 'code', label: 'Course Code' },
    { key: 'programId', label: 'Program ID' },
    { key: 'credits', label: 'Credits' },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Courses Management</h1>
          <p className="text-gray-600 mt-2">Manage academic courses</p>
        </div>
        
        <DataTable 
          endpoint="getCourses"
          title="All Courses"
          columns={courseColumns}
          service={adminService}
          createForm={CourseForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}