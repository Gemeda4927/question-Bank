'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import FacultyForm from '@/components/forms/FacultyForm';

export default function FacultyPage() {
  const facultyColumns = [
    { key: 'name', label: 'Faculty Name' },
    { key: 'email', label: 'Email' },
    { key: 'department', label: 'Department' },
    { key: 'universityId', label: 'University ID' },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Faculty Management</h1>
          <p className="text-gray-600 mt-2">Manage faculty members</p>
        </div>
        
        <DataTable 
          endpoint="getFaculties"
          title="All Faculty"
          columns={facultyColumns}
          service={adminService}
          createForm={FacultyForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}