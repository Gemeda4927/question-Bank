'use client';
import AdminLayout from '@/components/AdminLayout';
import ProtectedRoute from '@/components/ProtectedRoute';
import DataTable from '@/components/DataTable';
import { adminService } from '@/services/adminService';
import PaymentForm from '@/components/forms/PaymentForm';

export default function PaymentsPage() {
  const paymentColumns = [
    { key: 'userId', label: 'User ID' },
    { 
      key: 'amount', 
      label: 'Amount',
      render: (value: number) => `$${value.toFixed(2)}`
    },
    { key: 'paymentMethod', label: 'Method' },
    { 
      key: 'status', 
      label: 'Status',
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs ${
          value === 'completed' ? 'bg-green-100 text-green-800' :
          value === 'pending' ? 'bg-yellow-100 text-yellow-800' :
          value === 'failed' ? 'bg-red-100 text-red-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          {value.charAt(0).toUpperCase() + value.slice(1)}
        </span>
      )
    },
    { 
      key: 'createdAt', 
      label: 'Created At',
      render: (value: string) => new Date(value).toLocaleDateString()
    },
  ];

  return (
    <ProtectedRoute allowedRole="admin">
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Payments Management</h1>
          <p className="text-gray-600 mt-2">Manage payment records</p>
        </div>
        
        <DataTable 
          endpoint="getPayments"
          title="All Payments"
          columns={paymentColumns}
          service={adminService}
          createForm={PaymentForm}
        />
      </AdminLayout>
    </ProtectedRoute>
  );
}