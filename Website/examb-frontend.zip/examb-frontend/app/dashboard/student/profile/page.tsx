"use client";
import { useState, useEffect } from "react";
import ProtectedRoute from "@/components/ProtectedRoute";
import StudentLayout from "@/components/StudentLayout";
import { studentService } from "@/services/studentService";
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Award,
  BarChart3,
  CheckCircle,
  Edit2,
  Save,
  X,
  BookOpen,
  FileText,
  TrendingUp,
  AlertCircle,
  Shield,
  Clock,
} from "lucide-react";

// Enhanced Modal Components with better styling
const SuccessModal = ({
  isOpen,
  onClose,
  title,
  message,
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md transition-all duration-300">
      <div className="relative bg-gradient-to-br from-white to-gray-50 rounded-3xl shadow-2xl max-w-md w-full mx-4 transform transition-all duration-300 scale-95 animate-scaleIn overflow-hidden border border-gray-200/50">
        {/* Animated background elements */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-green-200/30 rounded-full blur-2xl"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-blue-200/30 rounded-full blur-2xl"></div>
        
        {/* Header */}
        <div className="relative bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-8 text-center overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-white/10 transform -skew-y-6 scale-150"></div>
          <div className="relative z-10">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm border-2 border-white/40 shadow-lg">
              <CheckCircle className="w-10 h-10 text-white drop-shadow-md" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2 drop-shadow-md">
              {title}
            </h3>
            <p className="text-green-100 font-medium">
              {message}
            </p>
          </div>
        </div>

        {/* Action */}
        <div className="relative p-6 text-center bg-white/80 backdrop-blur-sm">
          <button
            onClick={onClose}
            className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl hover:shadow-green-500/25 border-2 border-white/20"
          >
            <CheckCircle className="w-5 h-5 mr-2" />
            Continue
          </button>
        </div>
      </div>
    </div>
  );
};

const ErrorModal = ({
  isOpen,
  onClose,
  title,
  message,
  type = "error",
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  type?: "error" | "permission";
}) => {
  if (!isOpen) return null;

  const isPermissionError = type === "permission";
  const gradient = isPermissionError
    ? "from-amber-500 to-orange-600"
    : "from-rose-500 to-red-600";
  const icon = isPermissionError ? (
    <Shield className="w-10 h-10 text-white drop-shadow-md" />
  ) : (
    <AlertCircle className="w-10 h-10 text-white drop-shadow-md" />
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md transition-all duration-300">
      <div className="relative bg-gradient-to-br from-white to-gray-50 rounded-3xl shadow-2xl max-w-md w-full mx-4 transform transition-all duration-300 scale-95 animate-scaleIn overflow-hidden border border-gray-200/50">
        {/* Animated background elements */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-200/30 rounded-full blur-2xl"></div>
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-orange-200/30 rounded-full blur-2xl"></div>
        
        {/* Header */}
        <div className={`relative bg-gradient-to-r ${gradient} px-6 py-8 text-center overflow-hidden`}>
          <div className="absolute top-0 left-0 w-full h-full bg-white/10 transform -skew-y-6 scale-150"></div>
          <div className="relative z-10">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm border-2 border-white/40 shadow-lg">
              {icon}
            </div>
            <h3 className="text-2xl font-bold text-white mb-2 drop-shadow-md">
              {title}
            </h3>
            <p className="text-white/90 font-medium">
              {message}
            </p>
          </div>
        </div>

        {/* Action */}
        <div className="relative p-6 text-center bg-white/80 backdrop-blur-sm">
          <button
            onClick={onClose}
            className={`inline-flex items-center px-8 py-3 bg-gradient-to-r ${gradient} text-white font-semibold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-xl hover:shadow-2xl border-2 border-white/20`}
          >
            {isPermissionError ? (
              <Shield className="w-5 h-5 mr-2" />
            ) : (
              <AlertCircle className="w-5 h-5 mr-2" />
            )}
            Understand
          </button>
        </div>
      </div>
    </div>
  );
};

// Enhanced Loading Modal
const LoadingModal = ({
  isOpen,
  message,
}: {
  isOpen: boolean;
  message: string;
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md transition-all duration-300">
      <div className="relative bg-gradient-to-br from-white to-gray-50 rounded-3xl shadow-2xl p-8 max-w-sm w-full mx-4 text-center overflow-hidden border border-gray-200/50">
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-blue-200/30 rounded-full blur-2xl"></div>
        <div className="relative z-10">
          <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4 shadow-lg"></div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            Please Wait
          </h3>
          <p className="text-gray-600 font-medium">{message}</p>
        </div>
      </div>
    </div>
  );
};

export default function StudentProfilePage() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Modal states
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [showLoadingModal, setShowLoadingModal] = useState(false);
  const [modalContent, setModalContent] = useState({
    title: "",
    message: "",
    type: "error" as "error" | "permission",
  });

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    dateOfBirth: "",
  });

  // Enhanced stats with progress data
  const [enhancedStats, setEnhancedStats] = useState({
    courses: { current: 12, total: 20, progress: 60 },
    exams: { completed: 8, upcoming: 3, average: 84 },
    performance: { current: 84, target: 90, trend: "up" },
    streak: { days: 7, best: 14 }
  });

  useEffect(() => {
    fetchProfile();
  }, []);

  const showModal = (
    type: "success" | "error" | "permission",
    title: string,
    message: string
  ) => {
    setModalContent({
      title,
      message,
      type: type === "permission" ? "permission" : "error",
    });

    if (type === "success") {
      setShowSuccessModal(true);
    } else {
      setShowErrorModal(true);
    }
  };

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError("");

      // Try to get data from API first
      try {
        const response = await studentService.getProfile();
        const userData = response.data?.data || response.data;

        if (userData) {
          setProfile(userData);
          setFormData({
            name: userData.name || "",
            email: userData.email || "",
            phone: userData.phone || "",
            address: userData.address || "",
            dateOfBirth: userData.dateOfBirth
              ? formatDateForInput(userData.dateOfBirth)
              : "",
          });
        }
      } catch (apiError: any) {
        console.warn("API fetch failed, using localStorage data:", apiError);
        // Fallback to localStorage
        const studentFromStorage = getStudentFromStorage();
        if (studentFromStorage) {
          setProfile(studentFromStorage);
          setFormData({
            name: studentFromStorage.name || "",
            email: studentFromStorage.email || "",
            phone: studentFromStorage.phone || "",
            address: studentFromStorage.address || "",
            dateOfBirth: studentFromStorage.dateOfBirth
              ? formatDateForInput(studentFromStorage.dateOfBirth)
              : "",
          });
        }
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      setError("Failed to load profile data. Please refresh the page.");
    } finally {
      setLoading(false);
    }
  };

  const formatDateForInput = (dateString: string) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toISOString().split("T")[0];
  };

  const getStudentFromStorage = () => {
    if (typeof window !== "undefined") {
      const studentData = localStorage.getItem("student");
      return studentData ? JSON.parse(studentData) : null;
    }
    return null;
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError("");
      setSuccess("");
      setShowLoadingModal(true);

      // Validate required fields
      if (!formData.name.trim()) {
        setShowLoadingModal(false);
        showModal("error", "Missing Information", "Full name is required to update your profile.");
        return;
      }

      if (!formData.email.trim()) {
        setShowLoadingModal(false);
        showModal("error", "Missing Information", "Email address is required to update your profile.");
        return;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        setShowLoadingModal(false);
        showModal("error", "Invalid Email", "Please enter a valid email address to continue.");
        return;
      }

      console.log("📤 Sending update data:", formData);

      const response = await studentService.updateProfile(formData);
      console.log("✅ Update response:", response.data);

      // Update profile state with the response data
      const updatedData = response.data?.data || response.data || formData;
      const updatedProfile = { ...profile, ...updatedData };
      setProfile(updatedProfile);

      // Update localStorage
      const currentStudent = getStudentFromStorage() || {};
      const updatedStudent = {
        ...currentStudent,
        ...updatedData,
        lastUpdated: new Date().toISOString(),
      };
      localStorage.setItem("student", JSON.stringify(updatedStudent));

      setEditing(false);
      setShowLoadingModal(false);
      showModal("success", "Profile Updated!", "Your profile information has been successfully updated and saved.");
    } catch (error: any) {
      console.error("❌ Error updating profile:", error);
      setShowLoadingModal(false);

      // Extract error message from response
      const errorMessage = error.response?.data?.message || error.message || "Failed to update profile. Please check your connection and try again.";

      // Check for permission errors
      if (errorMessage.toLowerCase().includes("permission") || errorMessage.toLowerCase().includes("access denied") || errorMessage.toLowerCase().includes("unauthorized") || error.response?.status === 403) {
        showModal("permission", "Access Denied", "You do not have permission to perform this action. Please contact your administrator if you believe this is an error.");
      } else if (error.response?.status === 401) {
        showModal("error", "Session Expired", "Your session has expired. Please log in again to continue.");
      } else if (error.response?.status === 409) {
        showModal("error", "Email Conflict", "This email address is already registered. Please use a different email address.");
      } else {
        showModal("error", "Update Failed", errorMessage);
      }
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setEditing(false);
    setError("");
    setFormData({
      name: profile?.name || "",
      email: profile?.email || "",
      phone: profile?.phone || "",
      address: profile?.address || "",
      dateOfBirth: profile?.dateOfBirth ? formatDateForInput(profile.dateOfBirth) : "",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
    // Clear error when user starts typing
    if (error) setError("");
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case "courses":
        window.location.href = "/dashboard/student/courses";
        break;
      case "exams":
        window.location.href = "/dashboard/student/exams";
        break;
      case "results":
        window.location.href = "/dashboard/student/results";
        break;
      default:
        break;
    }
  };

  if (loading) {
    return (
      <ProtectedRoute allowedRole="student">
        <StudentLayout>
          <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600 mx-auto shadow-lg"></div>
              <p className="mt-4 text-gray-700 font-medium">Loading your profile...</p>
            </div>
          </div>
        </StudentLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute allowedRole="student">
      <StudentLayout>
        {/* Enhanced Modals */}
        <SuccessModal
          isOpen={showSuccessModal}
          onClose={() => setShowSuccessModal(false)}
          title={modalContent.title}
          message={modalContent.message}
        />

        <ErrorModal
          isOpen={showErrorModal}
          onClose={() => setShowErrorModal(false)}
          title={modalContent.title}
          message={modalContent.message}
          type={modalContent.type}
        />

        <LoadingModal
          isOpen={showLoadingModal}
          message="Updating your profile information..."
        />

        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 px-4 py-2">
          <div className="max-w-7xl mx-auto">
            {/* Compact Header Section */}
            <div className="text-center mb-4">
              <div className="inline-flex items-center justify-center w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl shadow-lg mb-3">
                <User className="w-7 h-7 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                My Profile
              </h1>
              <p className="text-gray-600 text-sm max-w-2xl mx-auto">
                Manage your account information and track academic progress
              </p>
            </div>

            <div className="grid lg:grid-cols-4 gap-4">
              {/* Left Column - Profile Information */}
              <div className="lg:col-span-3 space-y-4">
                {/* Compact Profile Card */}
                <div className="bg-gradient-to-br from-white to-gray-50/80 rounded-2xl shadow-xl border border-white/50 backdrop-blur-sm overflow-hidden">
                  {/* Compact Profile Header */}
                  <div className="relative bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 px-6 py-8 overflow-hidden">
                    <div className="absolute inset-0 bg-black/10"></div>
                    <div className="absolute -top-24 -right-24 w-48 h-48 bg-white/10 rounded-full blur-3xl"></div>
                    <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-300/20 rounded-full blur-3xl"></div>
                    
                    <div className="relative z-10 flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                      <div className="relative">
                        <div className="w-20 h-20 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm border-2 border-white/30 shadow-xl">
                          <User className="w-10 h-10 text-white" />
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                      </div>
                      <div className="text-white text-center md:text-left">
                        <h2 className="text-xl font-bold mb-2 drop-shadow-lg">
                          {profile?.name || "Not provided"}
                        </h2>
                        <p className="text-blue-100 mb-3 font-medium">
                          {profile?.email || "student@example.com"}
                        </p>
                        <div className="inline-flex items-center px-3 py-1 bg-white/20 rounded-xl text-sm font-semibold backdrop-blur-sm border border-white/30 shadow-lg">
                          <Award className="w-4 h-4 mr-1" />
                          {profile?.role ? profile.role.charAt(0).toUpperCase() + profile.role.slice(1) : "Student"}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Compact Personal Information Section */}
                  <div className="p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
                      <h3 className="text-lg font-bold text-gray-900 mb-3 sm:mb-0 flex items-center">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mr-3 shadow-md">
                          <User className="w-4 h-4 text-white" />
                        </div>
                        Personal Information
                      </h3>
                      {!editing ? (
                        <button
                          onClick={() => setEditing(true)}
                          className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg border border-white/20 text-sm"
                        >
                          <Edit2 className="w-4 h-4 mr-1" />
                          Edit Profile
                        </button>
                      ) : (
                        <div className="flex space-x-2">
                          <button
                            onClick={handleCancel}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all duration-300 disabled:opacity-50 shadow-sm text-sm"
                          >
                            <X className="w-4 h-4 mr-1" />
                            Cancel
                          </button>
                          <button
                            onClick={handleSave}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all duration-300 transform hover:scale-105 disabled:opacity-50 shadow-md hover:shadow-lg border border-white/20 text-sm"
                          >
                            {saving ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-1" />
                            ) : (
                              <Save className="w-4 h-4 mr-1" />
                            )}
                            {saving ? "Saving..." : "Save"}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      {/* Left Column Fields */}
                      <div className="space-y-4">
                        {/* Full Name */}
                        <div className="bg-white/50 rounded-xl p-1 shadow-sm border border-gray-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Full Name <span className="text-red-500">*</span>
                          </label>
                          {editing ? (
                            <input
                              type="text"
                              value={formData.name}
                              onChange={(e) => handleInputChange("name", e.target.value)}
                              className="w-full px-3 py-3 bg-transparent border-none rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 placeholder-gray-400 text-sm"
                              placeholder="Enter your full name"
                              required
                            />
                          ) : (
                            <div className="flex items-center p-3 rounded-xl">
                              <div className="w-10 h-10 bg-gradient-to-r from-blue-100 to-blue-200 rounded-lg flex items-center justify-center mr-3 shadow-sm">
                                <User className="w-5 h-5 text-blue-600" />
                              </div>
                              <span className="text-gray-900 font-semibold">
                                {profile?.name || "Not provided"}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Email Address */}
                        <div className="bg-white/50 rounded-xl p-1 shadow-sm border border-gray-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Email Address <span className="text-red-500">*</span>
                          </label>
                          {editing ? (
                            <input
                              type="email"
                              value={formData.email}
                              onChange={(e) => handleInputChange("email", e.target.value)}
                              className="w-full px-3 py-3 bg-transparent border-none rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 placeholder-gray-400 text-sm"
                              placeholder="Enter your email address"
                              required
                            />
                          ) : (
                            <div className="flex items-center p-3 rounded-xl">
                              <div className="w-10 h-10 bg-gradient-to-r from-green-100 to-green-200 rounded-lg flex items-center justify-center mr-3 shadow-sm">
                                <Mail className="w-5 h-5 text-green-600" />
                              </div>
                              <span className="text-gray-900 font-semibold">
                                {profile?.email || "Not provided"}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Phone Number */}
                        <div className="bg-white/50 rounded-xl p-1 shadow-sm border border-gray-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Phone Number
                          </label>
                          {editing ? (
                            <input
                              type="tel"
                              value={formData.phone}
                              onChange={(e) => handleInputChange("phone", e.target.value)}
                              className="w-full px-3 py-3 bg-transparent border-none rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 placeholder-gray-400 text-sm"
                              placeholder="Enter your phone number"
                            />
                          ) : (
                            <div className="flex items-center p-3 rounded-xl">
                              <div className="w-10 h-10 bg-gradient-to-r from-orange-100 to-orange-200 rounded-lg flex items-center justify-center mr-3 shadow-sm">
                                <Phone className="w-5 h-5 text-orange-600" />
                              </div>
                              <span className="text-gray-900 font-semibold">
                                {profile?.phone || "Not provided"}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right Column Fields */}
                      <div className="space-y-4">
                        {/* Date of Birth */}
                        <div className="bg-white/50 rounded-xl p-1 shadow-sm border border-gray-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Date of Birth
                          </label>
                          {editing ? (
                            <input
                              type="date"
                              value={formData.dateOfBirth}
                              onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                              className="w-full px-3 py-3 bg-transparent border-none rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 text-sm"
                            />
                          ) : (
                            <div className="flex items-center p-3 rounded-xl">
                              <div className="w-10 h-10 bg-gradient-to-r from-purple-100 to-purple-200 rounded-lg flex items-center justify-center mr-3 shadow-sm">
                                <Calendar className="w-5 h-5 text-purple-600" />
                              </div>
                              <span className="text-gray-900 font-semibold">
                                {profile?.dateOfBirth
                                  ? new Date(profile.dateOfBirth).toLocaleDateString("en-US", {
                                      year: "numeric",
                                      month: "short",
                                      day: "numeric",
                                    })
                                  : "Not provided"}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Address */}
                        <div className="bg-white/50 rounded-xl p-1 shadow-sm border border-gray-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Address
                          </label>
                          {editing ? (
                            <textarea
                              value={formData.address}
                              onChange={(e) => handleInputChange("address", e.target.value)}
                              rows={2}
                              className="w-full px-3 py-3 bg-transparent border-none rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all duration-300 resize-none placeholder-gray-400 text-sm"
                              placeholder="Enter your complete address"
                            />
                          ) : (
                            <div className="flex items-start p-3 rounded-xl">
                              <div className="w-10 h-10 bg-gradient-to-r from-red-100 to-red-200 rounded-lg flex items-center justify-center mr-3 shadow-sm mt-1">
                                <MapPin className="w-5 h-5 text-red-600" />
                              </div>
                              <span className="text-gray-900 font-semibold">
                                {profile?.address || "Not provided"}
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Role (Read-only) */}
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-1 shadow-sm border border-blue-100">
                          <label className="block text-xs font-semibold text-gray-700 mb-2 px-3 pt-3">
                            Role
                          </label>
                          <div className="flex items-center p-3 rounded-xl">
                            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mr-3 shadow-sm">
                              <Award className="w-5 h-5 text-white" />
                            </div>
                            <span className="text-blue-800 font-bold capitalize">
                              {profile?.role || "Student"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column - Compact Stats & Actions */}
              <div className="space-y-4">
                {/* Compact Academic Stats */}
                <div className="bg-gradient-to-br from-white to-gray-50/80 rounded-2xl shadow-xl border border-white/50 backdrop-blur-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mr-3 shadow-md">
                      <BarChart3 className="w-5 h-5 text-white" />
                    </div>
                    Academic Stats
                  </h3>
                  <div className="space-y-4">
                    {/* Course Progress */}
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100 shadow-sm">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center">
                          <BookOpen className="w-5 h-5 text-blue-600 mr-2" />
                          <span className="text-blue-800 font-semibold">Course Progress</span>
                        </div>
                        <span className="text-blue-900 font-bold text-xl">
                          {enhancedStats.courses.current}/{enhancedStats.courses.total}
                        </span>
                      </div>
                      <div className="w-full bg-blue-200 rounded-full h-2 mb-1">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-1000 ease-out"
                          style={{ width: `${enhancedStats.courses.progress}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-xs text-blue-700 font-medium">
                        <span>Progress</span>
                        <span>{enhancedStats.courses.progress}%</span>
                      </div>
                    </div>

                    {/* Exam Performance */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 border border-green-100 shadow-sm">
                      <div className="flex justify-between items-center mb-3">
                        <div className="flex items-center">
                          <FileText className="w-5 h-5 text-green-600 mr-2" />
                          <span className="text-green-800 font-semibold">Exam Performance</span>
                        </div>
                        <span className="text-green-900 font-bold text-xl">
                          {enhancedStats.exams.average}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-center">
                        <div>
                          <div className="text-green-700 font-bold">{enhancedStats.exams.completed}</div>
                          <div className="text-green-600 text-xs">Completed</div>
                        </div>
                        <div>
                          <div className="text-amber-600 font-bold">{enhancedStats.exams.upcoming}</div>
                          <div className="text-amber-600 text-xs">Upcoming</div>
                        </div>
                      </div>
                    </div>

                    {/* Learning Streak */}
                    <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-4 border border-amber-100 shadow-sm">
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center">
                          <Clock className="w-5 h-5 text-amber-600 mr-2" />
                          <span className="text-amber-800 font-semibold">Learning Streak</span>
                        </div>
                        <span className="text-amber-900 font-bold text-xl">
                          {enhancedStats.streak.days} days
                        </span>
                      </div>
                      <div className="text-amber-700 text-xs font-medium">
                        Best: {enhancedStats.streak.best} days • Keep going!
                      </div>
                    </div>
                  </div>
                </div>

                {/* Compact Quick Actions */}
                <div className="bg-gradient-to-br from-white to-gray-50/80 rounded-2xl shadow-xl border border-white/50 backdrop-blur-sm p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <button
                      onClick={() => handleQuickAction("courses")}
                      className="w-full flex items-center p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl hover:from-blue-100 hover:to-indigo-100 transition-all duration-300 transform hover:scale-105 font-semibold text-gray-800 border border-blue-100 hover:border-blue-200 shadow-sm hover:shadow-md text-sm"
                    >
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                        <BookOpen className="w-5 h-5 text-white" />
                      </div>
                      Browse Courses
                    </button>
                    <button
                      onClick={() => handleQuickAction("exams")}
                      className="w-full flex items-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl hover:from-green-100 hover:to-emerald-100 transition-all duration-300 transform hover:scale-105 font-semibold text-gray-800 border border-green-100 hover:border-green-200 shadow-sm hover:shadow-md text-sm"
                    >
                      <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                        <FileText className="w-5 h-5 text-white" />
                      </div>
                      View Exams
                    </button>
                    <button
                      onClick={() => handleQuickAction("results")}
                      className="w-full flex items-center p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-xl hover:from-purple-100 hover:to-violet-100 transition-all duration-300 transform hover:scale-105 font-semibold text-gray-800 border border-purple-100 hover:border-purple-200 shadow-sm hover:shadow-md text-sm"
                    >
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mr-3 shadow-sm">
                        <TrendingUp className="w-5 h-5 text-white" />
                      </div>
                      Check Results
                    </button>
                  </div>
                </div>

                {/* Compact Account Status */}
                <div className="bg-gradient-to-br from-blue-600 to-purple-700 rounded-2xl shadow-xl p-6 text-white overflow-hidden relative">
                  <div className="absolute -top-16 -right-16 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
                  <div className="relative z-10">
                    <h3 className="text-lg font-bold mb-3 flex items-center">
                      <div className="w-8 h-8 bg-white/20 rounded-xl flex items-center justify-center mr-2 backdrop-blur-sm">
                        <Shield className="w-4 h-4 text-white" />
                      </div>
                      Account Status
                    </h3>
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="w-6 h-6 bg-green-400 rounded-full flex items-center justify-center shadow-lg">
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                      <span className="font-bold text-xl">Active</span>
                    </div>
                    <p className="text-blue-100 text-xs font-medium">
                      Member since {profile?.createdAt
                        ? new Date(profile.createdAt).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })
                        : "N/A"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </StudentLayout>
    </ProtectedRoute>
  );
}